# Chocolate Doom para navegador: código fuente correspondiente

Runtime reutilizado sin modificaciones de https://github.com/lukaske/jev-doom-agent, commit `318c32a24851444c1170bf083671c38723f3a35a`. `vendor/chocolate-doom/` contiene el motor completo, sus modificaciones Emscripten y el puente `src/doom/browser_doom_bridge.c` (GPL-2.0-or-later). No se copia el controlador TypeScript de aquel proyecto.

## Compilar

Instalar Emscripten **4.0.14**, CMake y Ninja. Activar `emsdk_env.sh` y ejecutar desde esta carpeta:

```sh
bash engine/scripts/build_wasm.sh
```

El script original escribe los tres archivos en `public/engine/`. Incluimos `public/iwads/freedoom2.wad` (Freedoom 0.13.0) y las licencias/créditos en `licenses/`. No se requiere ningún WAD comercial. La compilación fuente no se ejecutó localmente: se validaron hashes de los binarios precompilados y su ejecución real en navegador.

El puente incorpora una escena controlada al reiniciar: MAP01, dificultad fácil, 100 salud/armadura y cuatro enemigos añadidos. Conserva la física y la asistencia de apuntado propias del motor clásico.

`browser-controller/` incluye el código fuente de nuestra integración y el adaptador de decisiones para inspección. El motor expone observaciones estructuradas; no envía imágenes al modelo.
