/** Build deterministic Doom-policy examples using real logits from the production model. */
import {mkdir,writeFile} from 'node:fs/promises';
import {createEngine} from '../src/node-engine.mjs';
import {decisionRequest} from '../src/doom-agent.mjs';
const out='research/doom-training';await mkdir(out,{recursive:true});
const actions=['SHOOT','TURN_LEFT','TURN_RIGHT','FORWARD','BACK','USE','DODGE_LEFT','DODGE_RIGHT'];
let seed=0x5eed1234;
const random=()=>((seed=(1664525*seed+1013904223)>>>0)/2**32);
const between=(a,b)=>Math.round(a+random()*(b-a));
function sensorFor(expected,index){
  const group=Math.floor(index/actions.length),variant=group%2;
  const sensor={health:between(25,100),armor:between(0,100),bullets:between(3,50),weapon:1,kills:between(0,8),enemies:0,target:null,
    front:between(100,1024),left:between(80,1024),right:between(80,1024),door:false,damage:0,stuck:false,
    x:between(-800,800),y:between(-800,800),gametic:between(100,5000),recentUse:false,useAttempts:0,stuckCount:0,underFire:false,damageStreak:0};
  if(expected==='SHOOT'){sensor.enemies=between(1,4);sensor.target={bearing:'center',distance:between(80,900)};}
  if(expected==='TURN_LEFT'){if(variant){sensor.enemies=1;sensor.target={bearing:'left',distance:between(60,700)};}else{sensor.stuck=group%4===0;sensor.stuckCount=between(2,4);sensor.front=between(16,100);sensor.left=between(500,1024);sensor.right=between(30,180);}}
  if(expected==='TURN_RIGHT'){if(variant){sensor.enemies=1;sensor.target={bearing:'right',distance:between(60,700)};}else{sensor.stuck=group%4===0;sensor.stuckCount=between(2,4);sensor.front=between(16,100);sensor.left=between(30,180);sensor.right=between(500,1024);}}
  if(expected==='FORWARD'){sensor.front=between(100,1024);if(variant){sensor.door=true;sensor.recentUse=true;sensor.useAttempts=between(1,3);sensor.front=between(25,160);}}
  if(expected==='BACK'){if(variant){sensor.front=between(10,55);}else{sensor.enemies=1;sensor.target={bearing:'center',distance:between(40,250)};sensor.bullets=0;}}
  if(expected==='USE'){sensor.door=true;sensor.front=between(20,63);}
  if(expected==='DODGE_LEFT'){sensor.damage=between(1,20);sensor.underFire=true;sensor.damageStreak=between(1,4);sensor.left=between(600,1024);sensor.right=between(30,180);if(variant){sensor.enemies=1;sensor.target={bearing:'center',distance:between(80,500)};}}
  if(expected==='DODGE_RIGHT'){sensor.damage=between(1,20);sensor.underFire=true;sensor.damageStreak=between(1,4);sensor.left=between(30,180);sensor.right=between(600,1024);if(variant){sensor.enemies=1;sensor.target={bearing:'center',distance:between(80,500)};}}
  return sensor;
}
const engine=await createEngine({calibration:false}),rows=[];
try{
  for(const [split,count] of [['train',800],['validation',160],['test',240]]){
    for(let i=0;i<count;i++){
      const expected=actions[i%actions.length],sensor=sensorFor(expected,i);
      const request=decisionRequest(sensor),answer=(await engine.evaluate(request)).answers.action;
      rows.push({id:`${split}:${i}`,split,expected,sensor,state:request.state,base_choice:answer.choice,base_probabilities:answer.probabilities});
      if((i+1)%100===0)console.log(`${split}: ${i+1}/${count}`);
    }
  }
}finally{await engine.scorer.session.release();}
await writeFile(`${out}/dataset.jsonl`,rows.map(r=>JSON.stringify(r)).join('\n')+'\n');
await writeFile(`${out}/dataset-manifest.json`,JSON.stringify({seed:'0x5eed1234',rows:rows.length,splits:Object.fromEntries(['train','validation','test'].map(s=>[s,rows.filter(r=>r.split===s).length])),actions,
  source:'Synthetic structured Doom observations scored by the unchanged production model; labels are a minimal supervised control specification.',
  holdout:'Test rows are generated after train/validation from an independent PRNG segment and are never used for fitting.'},null,2)+'\n');
console.log(`Prepared ${rows.length} observations with real logits.`);
