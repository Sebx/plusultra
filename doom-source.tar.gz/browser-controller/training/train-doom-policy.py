"""Train a tiny Doom action head over frozen GLiClass probabilities + visible sensors."""
import hashlib,json,random
from pathlib import Path
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'research/doom-training'; OUT=ROOT/'models/doom-policy'
ACTIONS=['SHOOT','TURN_LEFT','TURN_RIGHT','FORWARD','BACK','USE','DODGE_LEFT','DODGE_RIGHT']
FEATURES=[*[f'base_logp_{a.lower()}' for a in ACTIONS],'target_center','target_left','target_right','no_target','door','recent_use','stuck','front_near','left_open','right_open','bullets_available','use_attempts','stuck_count','under_fire','damage_streak']
def vector(r):
    s=r['sensor']; bearing=(s.get('target') or {}).get('bearing'); p=r['base_probabilities']
    return [*[np.log(max(1e-7,p[a])) for a in ACTIONS],bearing=='center',bearing=='left',bearing=='right',not s.get('target'),s['door'],s['recentUse'],s['stuck'],s['front']<64,min(1,s['left']/1024),min(1,s['right']/1024),s['bullets']>0,min(3,s['useAttempts'])/3,min(4,s.get('stuckCount',0))/4,s.get('underFire',False),min(4,s.get('damageStreak',0))/4]
def metrics(rows,pred):
    truth=np.array([ACTIONS.index(r['expected']) for r in rows]); result={'accuracy':float((pred==truth).mean()),'correct':int((pred==truth).sum()),'total':len(rows),'by_action':{}}
    for i,a in enumerate(ACTIONS):
        mask=truth==i;result['by_action'][a]={'correct':int((pred[mask]==truth[mask]).sum()),'total':int(mask.sum())}
    door=np.array([r['sensor']['recentUse'] for r in rows],bool);result['after_use_accuracy']=float((pred[door]==truth[door]).mean()) if door.any() else None
    result['repeated_use_after_use']=int(((pred==ACTIONS.index('USE'))&door).sum())
    under=np.array([r['sensor'].get('underFire',False) for r in rows],bool);result['under_fire_accuracy']=float((pred[under]==truth[under]).mean()) if under.any() else None
    stuck=np.array([r['sensor'].get('stuckCount',0)>=2 for r in rows],bool);result['stuck_recovery_accuracy']=float((pred[stuck]==truth[stuck]).mean()) if stuck.any() else None
    return result
random.seed(9271);np.random.seed(9271);torch.manual_seed(9271);torch.set_num_threads(2)
rows=[json.loads(x) for x in (DATA/'dataset.jsonl').read_text().splitlines()]
train=[r for r in rows if r['split']=='train'];valid=[r for r in rows if r['split']=='validation'];test=[r for r in rows if r['split']=='test']
raw=np.array([vector(r) for r in train],np.float32);mean=raw.mean(0);scale=raw.std(0);scale[scale<1e-6]=1
def tensors(part):
    x=(np.array([vector(r) for r in part],np.float32)-mean)/scale;y=np.array([ACTIONS.index(r['expected']) for r in part],np.int64);return torch.from_numpy(x),torch.from_numpy(y)
x,y=tensors(train);vx,vy=tensors(valid);tx,ty=tensors(test)
head=torch.nn.Linear(len(FEATURES),len(ACTIONS));opt=torch.optim.AdamW(head.parameters(),lr=0.025,weight_decay=0.002)
best=None;history=[]
for epoch in range(1,121):
    opt.zero_grad();loss=torch.nn.functional.cross_entropy(head(x),y,label_smoothing=.02);loss.backward();opt.step()
    with torch.no_grad(): val_loss=torch.nn.functional.cross_entropy(head(vx),vy).item();val_acc=(head(vx).argmax(1)==vy).float().mean().item()
    history.append({'epoch':epoch,'train_loss':loss.item(),'validation_loss':val_loss,'validation_accuracy':val_acc})
    if best is None or val_loss<best[0]:best=(val_loss,{k:v.detach().clone() for k,v in head.state_dict().items()},epoch)
head.load_state_dict(best[1]);
with torch.no_grad(): train_pred=head(x).argmax(1).numpy();valid_pred=head(vx).argmax(1).numpy();test_pred=head(tx).argmax(1).numpy()
model={'schema_version':1,'name':'doom-action-policy-v1','actions':ACTIONS,'features':FEATURES,'mean':mean.tolist(),'scale':scale.tolist(),'weights':head.weight.detach().numpy().tolist(),'bias':head.bias.detach().numpy().tolist(),
       'training':{'seed':9271,'selected_epoch':best[2],'trainable_parameters':sum(p.numel() for p in head.parameters()),'base_model_sha256':hashlib.sha256((ROOT/'models/decision/model.onnx').read_bytes()).hexdigest(),'dataset_sha256':hashlib.sha256((DATA/'dataset.jsonl').read_bytes()).hexdigest()}}
OUT.mkdir(parents=True,exist_ok=True);(OUT/'model.json').write_text(json.dumps(model,indent=2)+'\n')
test_metrics=metrics(test,test_pred)
report={'model':model['name'],'trainable_parameters':model['training']['trainable_parameters'],'selected_epoch':best[2],'train':metrics(train,train_pred),'validation':metrics(valid,valid_pred),'test':test_metrics,
        'promotion_gate':{'test_accuracy_at_least_98_percent':test_metrics['accuracy']>=.98,'no_repeated_use_after_use':test_metrics['repeated_use_after_use']==0,'under_fire_accuracy_at_least_98_percent':test_metrics['under_fire_accuracy']>=.98,'stuck_recovery_accuracy_at_least_98_percent':test_metrics['stuck_recovery_accuracy']>=.98},
        'scope':'Synthetic first-door-style observations. Adapter is Doom-only; the general decision model remains unchanged.'}
report['promotion_gate']['eligible']=all(report['promotion_gate'].values());(DATA/'training-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if not report['promotion_gate']['eligible']:raise SystemExit('Candidate did not pass promotion gate')
