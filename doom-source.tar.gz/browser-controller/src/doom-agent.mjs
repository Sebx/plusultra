/** Sensor projection and direct controls. No hidden policy, auto-aim or pathfinder. */
export const CONTROL_MASKS=Object.freeze({SHOOT:64,TURN_LEFT:4,TURN_RIGHT:8,FORWARD:1,BACK:2,DODGE_LEFT:16,DODGE_RIGHT:32,STRAFE_LEFT:16,STRAFE_RIGHT:32,USE:128});
export const ACTION_LABELS=Object.freeze({
  SHOOT:'enemy centered in the crosshair: shoot',
  TURN_LEFT:'enemy on the left: turn left',
  TURN_RIGHT:'enemy on the right: turn right',
  FORWARD:'empty open corridor: walk forward',
  BACK:'obstacle directly ahead: back away',
  USE:'door or switch within reach: use',
  DODGE_LEFT:'taking damage with more space on the left: dodge left',
  DODGE_RIGHT:'taking damage with more space on the right: dodge right',
});
const angleRadians = value => value / 0x100000000 * Math.PI * 2;
function rayDistance(player,lines,offset,accept=line=>line.blocking){
  const angle=angleRadians(player.angle)+offset,dx=Math.cos(angle),dy=Math.sin(angle);
  let distance=1024;
  for(const line of lines){
    if(!accept(line))continue;
    const sx=line.x2-line.x1,sy=line.y2-line.y1,det=dx*sy-dy*sx;
    if(Math.abs(det)<1e-8)continue;
    const qx=line.x1-player.x,qy=line.y1-player.y;
    const t=(qx*sy-qy*sx)/det,u=(qx*dy-qy*dx)/det;
    if(t>=0&&u>=0&&u<=1)distance=Math.min(distance,t);
  }
  return Math.round(distance);
}
export function observeDoom(observation,previous=null){
  if(!observation.ready||!observation.player)throw Error('Doom is not ready yet.');
  const p=observation.player,world=observation.world??{entities:[],lines:[]};
  const entities=world.entities.filter(e=>e.visible&&Math.abs(angleRadians(e.relative_angle))<=Math.PI/4);
  const enemies=entities.filter(e=>e.enemy&&e.health>0).sort((a,b)=>a.distance-b.distance);
  const nearest=enemies[0];
  const target=nearest?{distance:nearest.distance,bearing:Math.abs(nearest.relative_angle)<0x05000000?'center':nearest.relative_angle>0?'left':'right'}:null;
  // Doom's use action traces 64 units straight ahead; nearby lines behind us are irrelevant.
  const door=rayDistance(p,world.lines,0,line=>line.special!==0)<64;
  return {health:p.health,armor:p.armor,bullets:p.ammo.bullets,weapon:p.weapon,kills:p.kills,
    enemies:enemies.length,target,front:rayDistance(p,world.lines,0),left:rayDistance(p,world.lines,Math.PI/4),right:rayDistance(p,world.lines,-Math.PI/4),
    door,damage:p.recent_damage??0,stuck:!!(previous&&previous.moving&&Math.hypot(p.x-previous.x,p.y-previous.y)<2),
    x:p.x,y:p.y,gametic:observation.engine_state?.gametic??0};
}
export function decisionRequest(sensor){
  const sight=sensor.target?`A hostile monster is ${sensor.target.bearing==='center'?'directly ahead, centered in the crosshair':`visible on the ${sensor.target.bearing} of the camera`}.`:'The camera shows an empty corridor.';
  const state=[sight,
    ...(!sensor.target ? [sensor.front<64?'A solid wall blocks the path directly ahead.':'The corridor ahead is open.',sensor.door?'A door or switch is within reach.':''] : []),
    sensor.recentUse?'The door control was already used. Move through the doorway now; do not use it again.':'',
    sensor.stuckCount>=2?'Movement has failed repeatedly against a wall. Turn toward the more open side.':sensor.stuck?'The last movement was blocked.':'',
    sensor.underFire?'The player is taking damage. Dodge toward the more open side.':'',
    sensor.bullets===0?'The pistol has no bullets left.':'',
  ].filter(Boolean).join(' ');
  return {state,questions:{action:{type:'choice',instructions:'Select the next action in Doom.',criteria:ACTION_LABELS}}};
}
export class DoomActionMemory{
  constructor(){this.reset();}
  reset(){this.lastUse=null;this.useAttempts=0;this.pendingMovement=null;this.stuckCount=0;this.damageStreak=0;this.damageUntil=0;this.lastDamageGametic=null;}
  clearUse(){this.lastUse=null;this.useAttempts=0;}
  record(action,sensor){
    if(action==='USE'){
      this.lastUse={x:sensor.x,y:sensor.y,gametic:sensor.gametic};
      this.useAttempts++;
    }
    if(action==='FORWARD'||action==='BACK')this.pendingMovement={x:sensor.x,y:sensor.y,gametic:sensor.gametic};
    if(action==='TURN_LEFT'||action==='TURN_RIGHT'){this.pendingMovement=null;this.stuckCount=0;}
    if(action==='DODGE_LEFT'||action==='DODGE_RIGHT'){this.damageStreak=0;this.damageUntil=0;this.lastDamageGametic=null;}
  }
  enrich(sensor){
    if(this.lastUse){
      const moved=Math.hypot(sensor.x-this.lastUse.x,sensor.y-this.lastUse.y);
      const age=sensor.gametic-this.lastUse.gametic;
      if(moved>96||age<0||age>=140)this.clearUse();
    }
    if(this.pendingMovement){
      const age=sensor.gametic-this.pendingMovement.gametic;
      if(age<0)this.pendingMovement=null;
      else if(age>=4){
        const moved=Math.hypot(sensor.x-this.pendingMovement.x,sensor.y-this.pendingMovement.y);
        this.stuckCount=moved<3?Math.min(4,this.stuckCount+1):0;
        this.pendingMovement=null;
      }
    }
    if(sensor.damage>0&&sensor.gametic!==this.lastDamageGametic){
      this.damageStreak=Math.min(4,this.damageStreak+1);this.damageUntil=sensor.gametic+35;this.lastDamageGametic=sensor.gametic;
    }else if(sensor.damage<=0&&sensor.gametic>this.damageUntil){this.damageStreak=0;this.lastDamageGametic=null;}
    return {...sensor,recentUse:!!this.lastUse,useAttempts:this.useAttempts,stuckCount:this.stuckCount,damageStreak:this.damageStreak,underFire:this.damageStreak>0};
  }
}
export class DecisionGate{
  constructor(){this.epoch=0;this.pending=null;}
  begin(){if(this.pending!==null)return null;this.pending=++this.epoch;return this.pending;}
  invalidate(){this.epoch++;this.pending=null;}
  accept(id,action){if(id!==this.pending)return null;this.pending=null;if(!Object.hasOwn(CONTROL_MASKS,action))throw Error('The model returned an unknown action.');return CONTROL_MASKS[action];}
}
