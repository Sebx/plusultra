import { Tokenizer } from "@huggingface/tokenizers";
import { LIMITS } from "./core.mjs";

/** Runtime is injected: identical preparation and logits in Node and the Web. */
export class Encoder {
  constructor(ort, session, tokenizerJSON, tokenizerConfig) {
    this.ort = ort;
    this.session = session;
    this.tokenizer = new Tokenizer(tokenizerJSON, tokenizerConfig);
  }
  prepare(state, labels, prompt = "") {
    const sequence =
      labels.map((label) => "<<LABEL>>" + label).join("") +
      "<<SEP>>" +
      (prompt ? prompt + "\n" : "") +
      state;
    const { ids, attention_mask } = this.tokenizer.encode(sequence);
    if (ids.length > LIMITS.tokens)
      throw Error(
        `The question uses ${ids.length} tokens; the maximum is ${LIMITS.tokens}. Shorten the text or criteria.`,
      );
    if (
      ids.filter((v) => v === 256000).length !== labels.length ||
      ids.filter((v) => v === 256001).length !== 1
    )
      throw Error("Invalid control tokens.");
    return { ids, mask: attention_mask, count: labels.length };
  }
  async run({ ids, mask, count }) {
    const tensor = (values) =>
      new this.ort.Tensor("int64", BigInt64Array.from(values, BigInt), [
        1,
        values.length,
      ]);
    const result = await this.session.run({
      input_ids: tensor(ids),
      attention_mask: tensor(mask),
    });
    return Array.from(result.logits.data).slice(0, count);
  }
}
