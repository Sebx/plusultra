/** Adapted from Open-Jev metrics.py (MIT). See licenses/open-jev-MIT.txt.
 * These are concentration scores, NOT probabilities of correctness.
 */
export function choiceConfidence(p) {
  if (p.length === 1) return 1;
  const uniform = 1 / p.length;
  return (Math.max(...p) - uniform) / (1 - uniform);
}

export function scoreConfidence(p) {
  if (p.length === 1) return 1;
  const mode = p.indexOf(Math.max(...p));
  const distance = p.reduce(
    (sum, value, i) => sum + value * Math.abs(i - mode),
    0,
  );
  const center = (p.length - 1) / 2;
  const uniformDeviation =
    p.reduce((sum, _, i) => sum + Math.abs(i - center), 0) / p.length;
  return Math.max(0, 1 - distance / uniformDeviation);
}

export function applyTemperature(logits, temperature) {
  if (!Number.isFinite(temperature) || temperature <= 0)
    throw Error("Temperature must be positive and finite.");
  return logits.map((value) => value / temperature);
}
