/** Shared browser/API/CLI contract. The scorer returns logits, never text. */
import {
  choiceConfidence,
  scoreConfidence,
  applyTemperature,
} from "./decision-math.mjs";
export const MODEL_ID = "plusultra-gliclass-v1";
export const LIMITS = Object.freeze({
  tokens: 512,
  options: 25,
  questions: 16,
  bytes: 32768,
  candidates: 128,
});

export function softmax(values) {
  if (!values.length || !values.every(Number.isFinite))
    throw Error("The model returned invalid values.");
  const max = Math.max(...values),
    exp = values.map((v) => Math.exp(v - max)),
    sum = exp.reduce((a, b) => a + b, 0);
  return exp.map((v) => v / sum);
}
const object = (value) =>
  value !== null && typeof value === "object" && !Array.isArray(value);
function ordered(value) {
  if (typeof value === "number" && !Number.isFinite(value))
    throw Error("Non-finite numbers are not allowed.");
  if (Array.isArray(value)) return value.map(ordered);
  if (object(value))
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((k) => [k, ordered(value[k])]),
    );
  if (!["string", "number", "boolean"].includes(typeof value) && value !== null)
    throw Error("Valid JSON is required.");
  return value;
}
export const text = (value) =>
  typeof value === "string" ? value : JSON.stringify(ordered(value));
function description(value, nullable = false) {
  if (nullable && value === null) return;
  if (
    !(typeof value === "string" || object(value) || Array.isArray(value)) ||
    (typeof value === "string" ? !value.trim() : !Object.keys(value).length)
  )
    throw Error("Use non-empty text, object, or array values.");
  const t = text(value);
  if (/<<(?:LABEL|SEP|EXAMPLE)>>/.test(t))
    throw Error("The text contains reserved control tokens.");
}
export function validate(request) {
  if (!object(request)) throw Error("The request must be a JSON object.");
  if (request.model !== undefined && request.model !== MODEL_ID)
    throw Error("Unknown model: use " + MODEL_ID);
  description(request.state);
  if (new TextEncoder().encode(text(request.state)).length > LIMITS.bytes)
    throw Error("The state exceeds 32 KB.");
  if (!object(request.questions)) throw Error("questions must be an object.");
  const questions = Object.entries(request.questions);
  if (questions.length < 1 || questions.length > LIMITS.questions)
    throw Error("Use between 1 and 16 questions.");
  let count = 0;
  for (const [id, q] of questions) {
    if (!id || !object(q)) throw Error("Invalid question.");
    description(q.instructions);
    const c = q.criteria;
    if (q.type === "choice") {
      if (
        !object(c) ||
        !Object.keys(c).length ||
        Object.keys(c).length > LIMITS.options
      )
        throw Error("Choice accepts between 1 and 25 options.");
      for (const [key, value] of Object.entries(c)) {
        description(key);
        description(value, true);
      }
      count += Object.keys(c).length;
    } else if (q.type === "score") {
      if (!Array.isArray(c) || c.length < 2 || c.length > 10)
        throw Error("Score requires between 2 and 10 levels.");
      c.forEach((v) => description(v));
      count += c.length;
    } else if (q.type === "noul") {
      if (c !== undefined && c !== null) {
        if (!object(c) || Object.keys(c).sort().join(",") !== "false,true")
          throw Error("Noul requires true and false criteria.");
        Object.values(c).forEach((v) => description(v));
      }
      count += c ? 2 : 1;
    } else throw Error("Available types: choice, score, noul.");
  }
  if (count > LIMITS.candidates)
    throw Error("Maximum 128 candidates per request.");
}

export class DecisionEngine {
  constructor(scorer, { calibration = null, modelHash = null } = {}) {
    this.scorer = scorer;
    this.calibrations = new Map();
    if (calibration) {
      if (
        !/^[a-f0-9]{64}$/.test(modelHash ?? "") ||
        calibration.model_sha256 !== modelHash
      )
        throw Error("The calibration does not match these weights.");
      if (
        typeof calibration.scope !== "string" ||
        !calibration.scope.trim() ||
        !Array.isArray(calibration.profiles)
      )
        throw Error("Invalid calibration profile.");
      for (const profile of calibration.profiles) {
        if (
          profile.fit_split !== "calibration" ||
          !Number.isInteger(profile.samples) ||
          profile.samples < 1
        )
          throw Error("Only fits from the calibration split are accepted.");
        validate({ state: "validation", questions: { q: profile.question } });
        applyTemperature([0], profile.temperature);
        const key = text(profile.question);
        if (this.calibrations.has(key))
          throw Error("Duplicate calibration question.");
        this.calibrations.set(key, {
          temperature: profile.temperature,
          samples: profile.samples,
          scope: calibration.scope,
        });
      }
    }
  }
  async evaluate(request) {
    validate(request);
    // Preflight every question before executing any model work. Never truncate.
    const prepared = Object.entries(request.questions).map(([id, q]) => {
      const { keys, labels, prompt } = compileQuestion(q);
      return {
        id,
        q,
        keys,
        encoded: this.scorer.prepare(text(request.state), labels, prompt),
      };
    });
    const answers = [];
    const calibratedIds = [];
    for (const { id, q, keys, encoded } of prepared) {
      let logits = await this.scorer.run(encoded);
      if (logits.length !== keys.length || !logits.every(Number.isFinite))
        throw Error("Invalid model output.");
      const calibration = this.calibrations.get(text(q));
      if (calibration) {
        logits = applyTemperature(logits, calibration.temperature);
        calibratedIds.push(id);
      }
      if (q.type === "noul") {
        const p = q.criteria
          ? softmax(logits)[0]
          : 1 / (1 + Math.exp(-logits[0]));
        answers.push([
          id,
          { type: "noul", noul: p, ...(calibration ? { calibration } : {}) },
        ]);
        continue;
      }
      const p = softmax(logits);
      const a = {
        type: q.type,
        probabilities: Object.fromEntries(keys.map((k, i) => [k, p[i]])),
        confidence:
          q.type === "choice" ? choiceConfidence(p) : scoreConfidence(p),
        ...(calibration ? { calibration } : {}),
      };
      if (q.type === "choice") a.choice = keys[p.indexOf(Math.max(...p))];
      else {
        a.score = p.reduce((s, v, i) => s + i * v, 0);
        a.legend = Object.fromEntries(keys.map((k, i) => [k, q.criteria[i]]));
      }
      answers.push([id, a]);
    }
    return {
      model: MODEL_ID,
      answers: Object.fromEntries(answers),
      meta: {
        calibrated: calibratedIds.length === prepared.length,
        calibration_applied_questions: calibratedIds,
        generated_tokens: 0,
        confidence_method: "typesafe_adapter_choice_and_score",
        bonsai_distilled: false,
        status: calibratedIds.length
          ? "pretrained_scoped_temperature"
          : "pretrained_zero_shot",
      },
    };
  }
}

/** One compilation path for production, training and evaluation. */
export function compileQuestion(q) {
  let keys,
    labels,
    prompt = text(q.instructions);
  if (q.type === "choice") {
    keys = Object.keys(q.criteria);
    labels = keys.map((k) =>
      q.criteria[k] === null ? k : text(q.criteria[k]),
    );
  } else if (q.type === "score") {
    keys = q.criteria.map((_, i) => String(i));
    labels = q.criteria.map(text);
  } else if (q.criteria) {
    keys = ["true", "false"];
    labels = keys.map((k) => text(q.criteria[k]));
  } else {
    keys = ["true"];
    labels = [prompt];
    prompt = "";
  }
  return { keys, labels, prompt };
}
