/** Thin adapter to the unmodified GPL Chocolate Doom browser bridge. */
export async function bootDoom(canvas, onStatus){
  onStatus('Loading Doom and the Freedoom map…');
  const [data, {default:create}] = await Promise.all([
    fetch('/doom-engine/chocolate-doom.data').then(r=>{if(!r.ok)throw Error('Could not load Freedoom.');return r.arrayBuffer();}),
    import(/* webpackIgnore: true */ '/doom-engine/chocolate-doom.js'),
  ]);
  const logs=[];
  const module=await create({canvas,keyboardListeningElement:canvas,noInitialRun:true,
    locateFile:p=>'/doom-engine/'+p,getPreloadedPackage:()=>data,
    preRun:[m=>{
      m.FS.mkdir('/config');m.FS.mkdir('/savegames');
      m.FS.writeFile('/config/default.cfg','fullscreen 0\ngrabmouse 0\nuse_mouse 0\n');
      m.FS.writeFile('/config/chocolate-doom.cfg','aspect_ratio_correct 1\ninteger_scaling 0\nscreenblocks 10\nsmooth_pixel_scaling 0\nforce_software_renderer 1\nwindow_width 640\nwindow_height 480\n');
    }],print:line=>{logs.push(line);if(logs.length>20)logs.shift();},printErr:line=>{logs.push(line);if(logs.length>20)logs.shift();}});
  try{module.callMain(['-window','-iwad','/iwads/freedoom2.wad','-warp','1','-skill','1','-nomusic','-nosound','-config','/config/default.cfg','-extraconfig','/config/chocolate-doom.cfg']);}
  catch(e){if(!/unwind|SimulateInfiniteLoop/.test(String(e)))throw e;}
  const call=(name,...args)=>module.ccall(name,null,args.map(()=> 'number'),args);
  const observe=()=>JSON.parse(module.ccall('PromptFPS_Observation','string',[],[]));
  const started=performance.now();
  while(!observe().ready){if(performance.now()-started>15000)throw Error('Doom did not start: '+logs.join('\n'));await new Promise(r=>setTimeout(r,50));}
  call('PromptFPS_SetPaused',1);
  return {observe,controls:mask=>call('PromptFPS_SetControls',mask),pause:paused=>call('PromptFPS_SetPaused',+paused),
    reset:()=>{call('PromptFPS_SetControls',0);call('PromptFPS_SetStart');call('PromptFPS_SetPaused',1);},logs};
}
