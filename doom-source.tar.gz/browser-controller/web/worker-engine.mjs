import { Encoder } from "../src/encoder.mjs";
import { DecisionEngine } from "../src/core.mjs";
export function startWorker(ort, backend = "wasm") {
let engine;
let gpuSubmissions = 0, adapterInfo = null;
ort.env.wasm.numThreads = 1;
ort.env.wasm.wasmPaths = new URL("/runtime/", self.location.origin).href;
ort.env.logLevel = "error";
async function localFile(url) {
  let cache;
  try {
    cache = await caches.open(__MODEL_CACHE__);
  } catch {
    /* CacheStorage requires a secure context. */
  }
  let r = await cache?.match(url);
  if (!r) {
    try {
      r = await fetch(url);
    } catch {
      throw Error("File unavailable offline: " + url);
    }
    if (!r.ok) throw Error("Could not load " + url);
    try {
      await cache?.put(url, r.clone());
    } catch {
      /* UI verifies the complete cache after loading. */
    }
  }
  return r;
}
async function json(url) {
  return (await localFile(url)).json();
}
async function loadWeights() {
  const manifest = await json("/model/manifest.json");
  const model = new Uint8Array(manifest.files["model.onnx"].bytes);
  let offset = 0;
  for (const [index, part] of manifest.parts.entries()) {
    self.postMessage({
      type: "status",
      message: `Loading model: part ${index + 1} of ${manifest.parts.length}…`,
    });
    const bytes = new Uint8Array(
      await (await localFile("/model/" + part.name)).arrayBuffer(),
    );
    if (bytes.length !== part.bytes)
      throw Error("Incomplete model download.");
    if (crypto.subtle) {
      const digest = Array.from(
        new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)),
      )
        .map((v) => v.toString(16).padStart(2, "0"))
        .join("");
      if (digest !== part.sha256)
        throw Error(
          "The model weights failed the integrity check.",
        );
    }
    model.set(bytes, offset);
    offset += bytes.length;
  }
  if (offset !== model.length) throw Error("Incorrect model size.");
  return {
    model,
    manifest,
    paths: [
      "/model/manifest.json",
      ...manifest.parts.map((p) => "/model/" + p.name),
    ],
  };
}
self.onmessage = async ({ data }) => {
  try {
    if (data.type === "load") {
      self.postMessage({
        type: "status",
        message: "Loading model and tokenizer…",
      });
      const [weights, tokenizer, config] = await Promise.all([
        loadWeights(),
        json("/model/tokenizer.json"),
        json("/model/tokenizer_config.json"),
      ]);
      self.postMessage({
        type: "status",
        message: "Preparing the engine on this device…",
      });
      const session = await ort.InferenceSession.create(weights.model, {
        executionProviders: [backend],
        graphOptimizationLevel: "all",
      });
      if (backend === 'webgpu') {
        const device = await ort.env.webgpu.device;
        adapterInfo = device.adapterInfo ? {vendor:device.adapterInfo.vendor,architecture:device.adapterInfo.architecture,description:device.adapterInfo.description} : null;
        const submit = device.queue.submit.bind(device.queue);
        device.queue.submit = commands => {gpuSubmissions++; return submit(commands);};
      }
      engine = new DecisionEngine(
        new Encoder(ort, session, tokenizer, config),
        {
          calibration: weights.manifest.calibration,
          modelHash: weights.manifest.files["model.onnx"].sha256,
        },
      );
      self.postMessage({
        type: "ready",
        backend,
        adapter: adapterInfo,
        cachePaths: [
          ...weights.paths,
          "/model/tokenizer.json",
          "/model/tokenizer_config.json",
        ],
      });
    } else if (data.type === "evaluate") {
      if (!engine) throw Error("Load the local engine first.");
      const start = performance.now(),
        result = await engine.evaluate(data.request);
      self.postMessage({
        type: "result",
        id: data.id,
        request: data.request,
        result,
        latency: performance.now() - start,
        backend, gpuSubmissions, adapter: adapterInfo,
      });
    }
  } catch (error) {
    self.postMessage({
      type: "error",
      message: error.message,
      phase: data.type,
      id: data.id,
    });
  }
};

}
