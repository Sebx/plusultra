import {bootDoom} from './doom-engine.mjs';
import {observeDoom,decisionRequest,DecisionGate,DoomActionMemory} from '../src/doom-agent.mjs';
import {DoomPolicy} from '../src/doom-policy.mjs';
import policyModel from '../models/doom-policy/model.json' with {type:'json'};
const $=id=>document.getElementById(id);
const names={SHOOT:'Shoot',TURN_LEFT:'Turn left',TURN_RIGHT:'Turn right',FORWARD:'Move forward',BACK:'Move back',USE:'Use door or switch',DODGE_LEFT:'Dodge left',DODGE_RIGHT:'Dodge right'};
let game,worker,ready=false,running=false,manual=false,loading=false,lastSensor,previousMotion,
  playedMs=0,segmentStart=0,latestMask=0,releaseTimer,nextDecision=0,decisionCount=0,
  gpuSubmissions=0,gpuStartCounter=0,lastTick,lastTickTime,benchmarkStarted=null;
const gate=new DecisionGate(),history=[],latencies=[];
const actionMemory=new DoomActionMemory(),policy=new DoomPolicy(policyModel);
let backend='webgpu',adapter=null,loadStarted=0,loadMs=0,cachePaths=[];
function status(message){$('status').textContent=message;}
function error(message){$('error').textContent=message;$('error').hidden=!message;}
function controls(){
  $('load').disabled=loading||ready;$('backend').disabled=loading||ready;
  for(const id of ['play','reset','manual','benchmark'])$(id).disabled=!ready||loading;
  $('play').disabled||=running;
  $('pause').disabled=!ready||(!running&&!manual);
  $('download').disabled=history.length===0;
  $('live-dot').classList.toggle('active',running||manual);
  $('mode').textContent=running?'AI PLAYING':manual?'MANUAL CONTROL':ready?'PAUSED':'WAITING';
  $('manual-controls').hidden=!manual;
}
function halt(reason='Paused'){
  if(running||manual)playedMs+=performance.now()-segmentStart;
  running=false;manual=false;gate.invalidate();clearTimeout(releaseTimer);
  game?.controls(0);game?.pause(true);latestMask=0;status(reason);controls();
  if(benchmarkStarted?.status==='running')benchmarkStarted.status='paused';
  if(history.length)$('trace').textContent=JSON.stringify(report(),null,2);
}
function reset(){
  halt();game.reset();playedMs=0;history.length=0;latencies.length=0;decisionCount=0;
  previousMotion=null;lastSensor=null;lastTick=null;lastTickTime=null;benchmarkStarted=null;gpuStartCounter=gpuSubmissions;actionMemory.reset();
  $('game-message').hidden=true;$('decisions').textContent='0';$('elapsed').textContent='0:00';
  $('action').textContent='Waiting for the model';$('latency').textContent='—';
  $('probabilities').textContent='The distribution will appear during play.';$('trace').textContent='No decisions yet.';
  status('Scenario reset. You can let the AI play.');controls();
}
function play(){
  if(!ready)return;
  if((game.observe().player?.health??0)<=0||benchmarkStarted?.status==='completed')reset();
  if(manual)halt();
  running=true;manual=false;segmentStart=performance.now();nextDecision=0;
  if(benchmarkStarted?.status==='paused'||benchmarkStarted?.status==='ready')benchmarkStarted.status='running';
  game.pause(false);status('The AI is playing locally, with up to 4 decisions per second.');
  $('game-message').hidden=true;controls();
}
function statistics(){
  const sorted=[...latencies].sort((a,b)=>a-b),q=p=>sorted.length?sorted[Math.min(sorted.length-1,Math.floor(sorted.length*p))]:null;
  return {decisions:decisionCount,latency_p50_ms:q(.5),latency_p95_ms:q(.95),
    elapsed_seconds:(playedMs+((running||manual)?performance.now()-segmentStart:0))/1000,
    kills:lastSensor?.kills??0,health:lastSensor?.health??null,gpu_queue_submissions:gpuSubmissions-gpuStartCounter};
}
function report(){return {date:new Date().toISOString(),version:'0.4.0',
  model:'GLiClass Multilang Edge, unchanged 143M weights',model_bytes:277896593,
  policy:{name:policyModel.name,trainable_parameters:policyModel.training.trainable_parameters,base_model_sha256:policyModel.training.base_model_sha256,dataset_sha256:policyModel.training.dataset_sha256},
  engine:'Chocolate Doom 3.1.1 / Freedoom 0.13.0',scenario:'Controlled MAP01 with four spawned enemies; skill 1; health/armor 100',
  backend,adapter,gpu_work_observed:gpuSubmissions>gpuStartCounter,load_ms:loadMs,
  generated_tokens:0,raw_pixels_to_model:false,controller_autoaim:false,pathfinding:false,
  engine_aiming:'Unmodified classic Doom weapon aiming, including its built-in aim assist.',
  decisions_source:'Argmax of the trained Doom policy over frozen base-model scores and visible sensors; no heuristic fallback',
  memory_note:'No portable total RAM/VRAM measurement. Download size is not runtime memory.',
  hardware_validation:'Current browser only; not a physical 4 GB mobile test.',
  user_agent:navigator.userAgent,viewport:{width:innerWidth,height:innerHeight},
  benchmark:benchmarkStarted,statistics:statistics(),history};}
function displayDecision(data,mask,snapshot){
  const a=data.result.answers.action;
  $('action').textContent=names[a.choice]??a.choice;
  $('observation').textContent=snapshot.underFire?`Taking damage (streak ${snapshot.damageStreak}); more lateral space ${snapshot.left>snapshot.right?'on the left':'on the right'}.`:snapshot.stuckCount>=2?`Movement blocked ${snapshot.stuckCount} times; turn toward the open side.`:snapshot.target?`Enemy visible ${snapshot.target.bearing==='center'?'in the center':snapshot.target.bearing==='left'?'on the left':'on the right'}, ${snapshot.target.distance} units away.`:`Corridor ${snapshot.front<64?'blocked':'open'}; ${snapshot.door?'door or switch nearby':'no enemies in view'}.`;
  $('latency').textContent=data.latency.toFixed(0);$('decisions').textContent=String(decisionCount);
  $('probabilities').replaceChildren(...Object.entries(a.probabilities).sort((a,b)=>b[1]-a[1]).map(([key,value])=>{
    const row=document.createElement('div');row.className='prob'+(key===a.choice?' selected':'');
    const label=document.createElement('div'),name=document.createElement('span'),number=document.createElement('span');
    name.textContent=names[key]??key;number.textContent=(100*value).toFixed(1)+' %';label.append(name,number);
    const bar=document.createElement('progress');bar.max=1;bar.value=value;bar.setAttribute('aria-label',name.textContent);
    row.append(label,bar);return row;
  }));
  $('trace').textContent=JSON.stringify({statistics:statistics(),backend,adapter,generated_tokens:0,
    input:data.request,output:data.result,applied_controls:mask,gpu_queue_submissions:gpuSubmissions,latest_decisions:history.slice(-8)},null,2);
  $('download').disabled=false;
}
function applyResult(data){
  if(!running||data.id!==gate.pending)return;
  const base=data.result.answers.action,adapted=policy.evaluate(pendingSnapshot,base.probabilities);
  const a={...base,choice:adapted.choice,probabilities:adapted.probabilities,confidence:adapted.confidence,base_choice:base.choice,base_probabilities:base.probabilities,base_confidence:base.confidence,policy:policyModel.name};
  data={...data,result:{...data.result,answers:{...data.result.answers,action:a}}};
  const mask=gate.accept(data.id,a.choice);
  if(mask===null)return;
  if(backend==='webgpu'&&!(data.gpuSubmissions>gpuSubmissions))throw Error('The GPU recorded no work for this decision. Select CPU before reloading; the engine does not switch automatically.');
  gpuSubmissions=data.gpuSubmissions??0;
  $('gpu-badge').textContent=backend==='webgpu'?'● GPU active · trained policy':'● CPU active · trained policy';
  const now=performance.now();latencies.push(data.latency);if(latencies.length>1000)latencies.shift();decisionCount++;
  const observation=observeDoom(game.observe());
  // No steering toward coordinates: this is the exact keyboard mask selected by the model.
  latestMask=mask;game.controls(mask);clearTimeout(releaseTimer);
  actionMemory.record(a.choice,pendingSnapshot);
  const duration=(mask===4||mask===8)?85:180;
  releaseTimer=setTimeout(()=>{game?.controls(0);latestMask=0;},duration);
  history.push({id:data.id,at_seconds:statistics().elapsed_seconds,choice:a.choice,mask,
    latency_ms:data.latency,confidence:a.confidence,probabilities:a.probabilities,base_choice:a.base_choice,base_probabilities:a.base_probabilities,policy:a.policy,
    observed:pendingSnapshot,applied_at_gametic:observation.gametic,gpu_queue_submissions:gpuSubmissions});
  if(history.length>1000)history.shift();
  displayDecision(data,mask,pendingSnapshot);
  nextDecision=now+Math.max(20,250-data.latency);
}
let pendingSnapshot;
async function load(){
  loading=true;error('');backend=$('backend').value;loadStarted=performance.now();controls();
  try{
    if(backend==='webgpu'&&!(await navigator.gpu?.requestAdapter()))throw Error('WebGPU is unavailable in this browser. Use an updated Chrome/Edge or select WebAssembly to play on CPU.');
    if('serviceWorker' in navigator){await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;
      if(!navigator.serviceWorker.controller)await new Promise(resolve=>navigator.serviceWorker.addEventListener('controllerchange',resolve,{once:true}));}
    if(!game){game=await bootDoom($('doom'),status);game.reset();$('cover').hidden=true;}
    worker?.terminate();worker=new Worker(backend==='webgpu'?'/gpu-worker.js':'/worker.js',{type:'module'});
    worker.onmessage=async({data})=>{
      try{
        if(data.type==='status')status(data.message);
        if(data.type==='ready'){
          adapter=data.adapter??null;cachePaths=data.cachePaths;ready=true;loading=false;loadMs=performance.now()-loadStarted;
          status('Ready. The game and AI run on this device.');controls();
          $('gpu-badge').textContent=backend==='webgpu'?'WebGPU ready · waiting for inference':'CPU ready';
          await checkOffline();
        }
        if(data.type==='result')applyResult(data);
        if(data.type==='error')throw Error(data.message);
      }catch(e){halt('Execution stopped');loading=false;error(e.message);controls();}
    };
    worker.onerror=e=>{halt('Engine error');loading=false;error(e.message);controls();};
    worker.postMessage({type:'load'});
  }catch(e){loading=false;error(e.message);controls();}
}
async function checkOffline(){
  const runtime=backend==='webgpu'?'ort-wasm-simd-threaded.asyncify':'ort-wasm-simd-threaded';
  const paths=[...cachePaths,'/doom.html','/doom.js','/doom.css',backend==='webgpu'?'/gpu-worker.js':'/worker.js',
    `/runtime/${runtime}.mjs`,`/runtime/${runtime}.wasm`,...['js','wasm','data'].map(ext=>'/doom-engine/chocolate-doom.'+ext)];
  try{
    const hits=await Promise.all(paths.map(p=>caches.match(p)));
    $('offline').textContent=hits.every(Boolean)?'Stored. You can reload this demo offline.':'Storage incomplete: keep this tab open if you disconnect.';
  }catch{$('offline').textContent='Cache unavailable in this browser.';}
}
setInterval(()=>{
  if(!game||loading)return;
  try{
    const o=game.observe();lastSensor=actionMemory.enrich(observeDoom(o,previousMotion));
    previousMotion={x:lastSensor.x,y:lastSensor.y,moving:(latestMask&3)!==0};
    for(const [id,value]of Object.entries({health:lastSensor.health,armor:lastSensor.armor,kills:lastSensor.kills,ammo:lastSensor.bullets}))$(id).textContent=String(value);
    const now=performance.now();
    if(lastTickTime&&now-lastTickTime>=1000){$('tick-rate').textContent=((lastSensor.gametic-lastTick)*1000/(now-lastTickTime)).toFixed(0);lastTickTime=now;lastTick=lastSensor.gametic;}
    if(!lastTickTime){lastTickTime=now;lastTick=lastSensor.gametic;}
    const seconds=Math.floor(statistics().elapsed_seconds);$('elapsed').textContent=Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');
    if((running||manual)&&lastSensor.health<=0){if(benchmarkStarted)benchmarkStarted.status='died';halt('The player died. Reset the scenario to try again.');$('game-message').textContent='Game over · '+lastSensor.kills+' kills';$('game-message').hidden=false;}
    if(running&&benchmarkStarted?.status==='running'&&statistics().elapsed_seconds>=60){benchmarkStarted.status='completed';halt('60-second test completed. Download the measurement.');$('game-message').textContent='Test completed';$('game-message').hidden=false;}
    if(running&&now>=nextDecision&&gate.pending===null){
      const id=gate.begin();pendingSnapshot={...lastSensor};
      worker.postMessage({type:'evaluate',id,request:decisionRequest(lastSensor)});
    }
  }catch(e){halt('Execution stopped');error(e.message);}
},100);
$('load').onclick=load;$('play').onclick=play;$('pause').onclick=()=>halt();$('reset').onclick=reset;
$('manual').onclick=()=>{if(benchmarkStarted)benchmarkStarted.status='interrupted_by_manual_control';halt();manual=true;segmentStart=performance.now();game.pause(false);status('Manual control. The AI is stopped.');controls();$('doom').focus();};
$('benchmark').onclick=()=>{reset();benchmarkStarted={duration_target_seconds:60,started_at:new Date().toISOString(),status:'ready'};play();};
for(const button of document.querySelectorAll('[data-mask]')){
  button.addEventListener('pointerdown',e=>{if(!manual)return;e.preventDefault();button.setPointerCapture(e.pointerId);game.controls(+button.dataset.mask);});
  for(const type of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(type,()=>{if(manual)game.controls(0);});
}
$('download').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(report(),null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='plusultra-doom-measurement.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&(running||manual))halt('Paused after leaving the tab.');});
window.addEventListener('pagehide',()=>{halt();worker?.terminate();});
controls();
