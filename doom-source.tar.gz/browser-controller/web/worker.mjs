import * as ort from "onnxruntime-web/wasm";
import {startWorker} from "./worker-engine.mjs";
startWorker(ort);
