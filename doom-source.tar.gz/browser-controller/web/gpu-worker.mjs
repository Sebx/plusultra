import * as ort from "onnxruntime-web/webgpu";
import {startWorker} from "./worker-engine.mjs";
startWorker(ort, "webgpu");
